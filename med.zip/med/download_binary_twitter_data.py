#!/usr/bin/python




filename='smm4h-EMNLP-task1-trainingset.csv'
files=['task3_trainingset1_download_form.txt','task3_trainingset2_download_form.txt','task3_trainingset3_download_form.txt']
data=[]
for filename in files:
    with open(filename,'r') as f:
        data+=[x.split('\t')[0] for x in f.readlines()]

with open('trainid3','w') as f:
    for i in data:
        f.write(i+'\n')












































